import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { Bell, Menu, Plus, Clock, Search, Briefcase, Zap, X } from "lucide-react";
import { cn, Button } from "@/components/ui/core";
import { useTasks } from "@/hooks/use-tasks";
import { useNotifications } from "@/hooks/use-notifications";
import { formatDistanceToNow } from "date-fns";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [location] = useLocation();
  const { data: tasks } = useTasks();
  const { data: notifications } = useNotifications();

  const unreadCount = notifications?.filter(n => !n.read).length || 0;

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden text-foreground">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed md:static inset-y-0 left-0 z-50 w-72 bg-card border-r border-border transform transition-transform duration-300 ease-in-out flex flex-col",
        sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      )}>
        <div className="flex items-center justify-between p-6">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground group-hover:scale-110 transition-transform" />
            </div>
            <span className="font-display font-bold text-xl tracking-widest text-primary">DONNA</span>
          </Link>
          <button className="md:hidden text-muted-foreground" onClick={() => setSidebarOpen(false)}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-4 pb-4">
          <Link href="/">
            <Button variant="secondary" className="w-full justify-start text-muted-foreground hover:text-foreground">
              <Plus className="w-4 h-4 mr-3" />
              New Request
            </Button>
          </Link>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-2 space-y-8 scrollbar-hide">
          
          <div>
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2">
              Recent Activity
            </h4>
            <div className="space-y-1">
              {tasks?.slice(0, 5).map(task => (
                <Link key={task.id} href={`/tasks/${task.id}`} 
                  className={cn(
                    "flex items-center w-full px-3 py-2 text-sm rounded-lg transition-colors",
                    location === `/tasks/${task.id}` ? "bg-accent text-foreground" : "text-muted-foreground hover:bg-accent/50 hover:text-foreground"
                  )}
                >
                  <Briefcase className="w-4 h-4 mr-3 opacity-70" />
                  <span className="truncate flex-1">{task.query}</span>
                </Link>
              ))}
              {tasks?.length === 0 && (
                <div className="text-sm text-muted-foreground px-3 py-2 italic">No recent tasks</div>
              )}
            </div>
          </div>

          <div>
            <h4 className="flex items-center justify-between text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2">
              <span>Updates</span>
              {unreadCount > 0 && (
                <span className="bg-primary text-primary-foreground text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                  {unreadCount}
                </span>
              )}
            </h4>
            <div className="space-y-2">
              {notifications?.slice(0, 4).map(notif => (
                <div key={notif.id} className="p-3 rounded-xl bg-accent/30 border border-white/5">
                  <p className="text-xs text-foreground/90 leading-relaxed mb-1">{notif.message}</p>
                  <span className="text-[10px] text-muted-foreground">
                    {formatDistanceToNow(new Date(notif.createdAt || Date.now()), { addSuffix: true })}
                  </span>
                </div>
              ))}
              {notifications?.length === 0 && (
                <div className="text-sm text-muted-foreground px-3 py-2 italic">All caught up.</div>
              )}
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-3 px-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-zinc-700 to-zinc-500 border border-white/10" />
            <div>
              <p className="text-sm font-medium">Harvey S.</p>
              <p className="text-xs text-muted-foreground">Managing Partner</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-zinc-900/20 via-background to-background">
        <header className="h-16 flex items-center justify-between px-4 md:px-8 border-b border-border/50 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button className="md:hidden text-foreground" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="font-display font-semibold text-lg hidden md:block">Workspace</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground">
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full animate-pulse" />
              )}
            </Button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto relative">
          {children}
        </div>
      </main>
    </div>
  );
}
