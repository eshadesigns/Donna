import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { Business } from "@shared/schema";

export function useBusinesses(taskId: number | null) {
  return useQuery({
    queryKey: [api.businesses.list.path, taskId],
    queryFn: async () => {
      const url = buildUrl(api.businesses.list.path, { taskId: taskId! });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch businesses");
      return res.json() as Promise<Business[]>;
    },
    enabled: taskId !== null,
  });
}
