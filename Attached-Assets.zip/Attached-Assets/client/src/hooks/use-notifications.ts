import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import type { Notification } from "@shared/schema";

export function useNotifications() {
  return useQuery({
    queryKey: [api.notifications.list.path],
    queryFn: async () => {
      const res = await fetch(api.notifications.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch notifications");
      return res.json() as Promise<Notification[]>;
    },
    // Poll every 5 seconds for MVP async updates
    refetchInterval: 5000,
  });
}
