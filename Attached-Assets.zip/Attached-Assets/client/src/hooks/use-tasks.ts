import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { Task, InsertTask } from "@shared/schema";

// Helper to handle parsing safely
async function fetchAndParse<T>(url: string, method = "GET", body?: any): Promise<T> {
  const res = await fetch(url, {
    method,
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    credentials: "include",
  });
  
  if (!res.ok) {
    const error = await res.json().catch(() => ({ message: "An error occurred" }));
    throw new Error(error.message || "Failed to fetch");
  }
  
  return res.json();
}

export function useTasks() {
  return useQuery({
    queryKey: [api.tasks.list.path],
    queryFn: () => fetchAndParse<Task[]>(api.tasks.list.path),
  });
}

export function useTask(id: number | null) {
  return useQuery({
    queryKey: [api.tasks.get.path, id],
    queryFn: () => fetchAndParse<Task>(buildUrl(api.tasks.get.path, { id: id! })),
    enabled: id !== null,
  });
}

export function useCreateTask() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertTask) => fetchAndParse<Task>(api.tasks.create.path, api.tasks.create.method, data),
    onSuccess: (newTask) => {
      queryClient.invalidateQueries({ queryKey: [api.tasks.list.path] });
      queryClient.setQueryData([api.tasks.get.path, newTask.id], newTask);
    },
  });
}

export function useUpdateTask() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...updates }: { id: number } & Partial<InsertTask>) => {
      return fetchAndParse<Task>(buildUrl(api.tasks.update.path, { id }), api.tasks.update.method, updates);
    },
    onSuccess: (updatedTask) => {
      queryClient.invalidateQueries({ queryKey: [api.tasks.list.path] });
      queryClient.setQueryData([api.tasks.get.path, updatedTask.id], updatedTask);
    },
  });
}
