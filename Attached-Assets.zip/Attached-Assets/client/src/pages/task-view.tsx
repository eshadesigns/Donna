import React, { useEffect, useRef, useState } from "react";
import { useRoute } from "wouter";
import { AppLayout } from "@/components/layout/app-layout";
import { useTask, useUpdateTask } from "@/hooks/use-tasks";
import { useBusinesses } from "@/hooks/use-businesses";
import { Card, Button, Input } from "@/components/ui/core";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, Phone, MapPin, Star, ChevronRight, CheckCircle2, SlidersHorizontal, User } from "lucide-react";
import type { Task } from "@shared/schema";

export default function TaskView() {
  const [, params] = useRoute("/tasks/:id");
  const taskId = params?.id ? parseInt(params.id, 10) : null;
  const { data: task, isLoading } = useTask(taskId);
  const { data: businesses } = useBusinesses(taskId);
  const updateTask = useUpdateTask();
  
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [task?.status, task?.context]);

  if (isLoading || !task) {
    return (
      <AppLayout>
        <div className="h-full flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="flex flex-col h-full max-w-4xl mx-auto w-full">
        {/* MVP Dev Tools - To simulate backend state machine */}
        <div className="absolute top-4 right-8 z-50 flex items-center gap-2 bg-card border border-border rounded-lg p-2 shadow-xl">
          <SlidersHorizontal className="w-4 h-4 text-muted-foreground mr-2" />
          <span className="text-xs text-muted-foreground uppercase font-bold tracking-widest mr-2">Status:</span>
          {(['clarifying', 'researching', 'calling', 'done'] as const).map(status => (
            <button
              key={status}
              onClick={() => updateTask.mutate({ id: task.id, status })}
              className={`text-xs px-2 py-1 rounded transition-colors ${task.status === status ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-accent'}`}
            >
              {status}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8 pb-32">
          
          {/* 1. User Original Query */}
          <div className="flex justify-end">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-[80%] bg-accent text-accent-foreground px-6 py-4 rounded-2xl rounded-tr-sm shadow-md"
            >
              <p className="text-[15px] leading-relaxed">{task.query}</p>
            </motion.div>
          </div>

          {/* 2. Donna's Responses based on Status Workflow */}
          <AnimatePresence mode="popLayout">
            
            {/* Clarifying State */}
            {['clarifying', 'researching', 'calling', 'done'].includes(task.status) && (
              <motion.div
                key="clarifying"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start gap-4"
              >
                <Avatar />
                <div className="space-y-4 max-w-[85%]">
                  <div className="bg-card border border-white/5 px-6 py-4 rounded-2xl rounded-tl-sm shadow-lg">
                    <p className="text-[15px] text-foreground/90">I can certainly handle that. To ensure I get the best options, I need a few more details.</p>
                  </div>
                  
                  {task.status === 'clarifying' && (
                    <ClarifyingCards task={task} />
                  )}
                  
                  {/* Show answered context if any */}
                  {Object.entries(task.context || {}).length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {Object.entries(task.context || {}).map(([key, val]) => (
                        <span key={key} className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium border border-primary/20">
                          {key}: {val as string} <CheckCircle2 className="w-3 h-3 ml-1" />
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Researching State */}
            {['researching', 'calling', 'done'].includes(task.status) && (
              <motion.div
                key="researching"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start gap-4 mt-6"
              >
                <Avatar />
                <div className="bg-card border border-white/5 px-6 py-4 rounded-2xl rounded-tl-sm shadow-lg flex items-center gap-4">
                  {task.status === 'researching' ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin text-primary" />
                      <p className="text-[15px] text-foreground/90 italic">On it. Researching top venues matching your criteria...</p>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                      <p className="text-[15px] text-muted-foreground line-through">Research complete.</p>
                    </>
                  )}
                </div>
              </motion.div>
            )}

            {/* Calling State */}
            {['calling', 'done'].includes(task.status) && (
              <motion.div
                key="calling"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start gap-4 mt-6"
              >
                <Avatar />
                <div className="bg-card border border-white/5 px-6 py-4 rounded-2xl rounded-tl-sm shadow-lg flex items-center gap-4">
                  {task.status === 'calling' ? (
                    <>
                      <div className="relative">
                        <Phone className="w-5 h-5 text-primary relative z-10" />
                        <span className="absolute inset-0 bg-primary/30 rounded-full animate-ping-slow"></span>
                      </div>
                      <p className="text-[15px] text-foreground/90 italic">Donna is on the phone verifying availability...</p>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                      <p className="text-[15px] text-muted-foreground line-through">Availability verified.</p>
                    </>
                  )}
                </div>
              </motion.div>
            )}

            {/* Done State */}
            {task.status === 'done' && (
              <motion.div
                key="done"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start gap-4 mt-6"
              >
                <Avatar />
                <div className="space-y-4 max-w-full md:max-w-[85%] w-full">
                  <div className="bg-card border border-white/5 px-6 py-4 rounded-2xl rounded-tl-sm shadow-lg">
                    <p className="text-[15px] text-foreground/90">I've secured the details. Here are the top options that meet your exact requirements.</p>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                    {businesses?.map((biz, i) => (
                      <motion.div 
                        key={biz.id}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.1 }}
                      >
                        <Card className="p-5 hover:border-primary/50 transition-colors flex flex-col h-full relative overflow-hidden group">
                          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 blur-[50px] group-hover:bg-primary/10 transition-colors pointer-events-none" />
                          <div className="flex justify-between items-start mb-3">
                            <h3 className="font-display font-bold text-lg">{biz.name}</h3>
                            <div className="flex items-center bg-accent px-2 py-1 rounded text-xs font-bold text-yellow-500">
                              <Star className="w-3 h-3 mr-1 fill-current" /> {biz.rating || "4.8"}
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground mb-4 flex-1">{biz.details}</p>
                          <div className="flex items-center justify-between mt-auto pt-4 border-t border-border">
                            <span className="text-xs text-muted-foreground flex items-center">
                              <MapPin className="w-3 h-3 mr-1" /> {biz.distance || "1.2 mi"}
                            </span>
                            <Button size="sm" variant={i === 0 ? "primary" : "secondary"}>
                              {biz.isBookingAvailableOnline ? "Book Now" : "Request Call"}
                            </Button>
                          </div>
                        </Card>
                      </motion.div>
                    ))}
                    {(!businesses || businesses.length === 0) && (
                      <div className="col-span-2 p-8 text-center text-muted-foreground border border-dashed border-border rounded-xl">
                        No businesses found.
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>

          <div ref={endOfMessagesRef} />
        </div>

        {/* Floating Chat Input (Disabled if done, or used for followups) */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-background via-background to-transparent md:left-72">
          <div className="max-w-4xl mx-auto">
            <Input 
              placeholder={task.status === 'done' ? "Need anything else?" : "Type to reply..."} 
              className="bg-card/80 backdrop-blur-xl border-white/10 shadow-2xl h-14 rounded-2xl"
            />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

// ----------------------------------------------------------------------
// Sub-components
// ----------------------------------------------------------------------

function Avatar() {
  return (
    <div className="w-10 h-10 shrink-0 rounded-full bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
      <Zap className="w-5 h-5 text-primary-foreground" />
    </div>
  );
}

function ClarifyingCards({ task }: { task: Task }) {
  const updateTask = useUpdateTask();
  const [val, setVal] = useState("");
  const [activeCard, setActiveCard] = useState<string | null>(null);

  const handleAnswer = (key: string, value: string) => {
    updateTask.mutate({
      id: task.id,
      context: { ...((task.context as Record<string, string>) || {}), [key]: value }
    });
    setVal("");
    setActiveCard(null);
  };

  const questions = [
    { key: "Location", label: "Neighborhood or Area?", icon: MapPin },
    { key: "Time", label: "Preferred Time?", icon: Clock },
    { key: "Party Size", label: "How many people?", icon: User },
  ];

  // Filter out already answered questions
  const unanswered = questions.filter(q => !((task.context as Record<string, string>) || {})[q.key]);

  if (unanswered.length === 0 && task.status === 'clarifying') {
    // If all standard questions answered, prompt to proceed
    return (
      <Button 
        onClick={() => updateTask.mutate({ id: task.id, status: 'researching' })}
        className="w-full mt-2"
      >
        Looks good, start researching <ChevronRight className="w-4 h-4 ml-2" />
      </Button>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
      {unanswered.map((q) => (
        <Card 
          key={q.key} 
          className={`p-4 cursor-pointer transition-all hover:border-primary/50 ${activeCard === q.key ? 'ring-1 ring-primary border-primary' : ''}`}
          onClick={() => setActiveCard(q.key)}
        >
          <div className="flex items-center mb-2">
            <q.icon className="w-4 h-4 text-muted-foreground mr-2" />
            <span className="font-medium text-sm text-foreground/80">{q.label}</span>
          </div>
          
          {activeCard === q.key ? (
            <div className="flex items-center gap-2 mt-3" onClick={e => e.stopPropagation()}>
              <Input 
                autoFocus
                size={1}
                className="h-8 text-sm" 
                placeholder="Type..." 
                value={val}
                onChange={e => setVal(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && val.trim()) {
                    handleAnswer(q.key, val.trim());
                  }
                }}
              />
              <Button size="sm" onClick={() => val.trim() && handleAnswer(q.key, val.trim())}>Save</Button>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground mt-1">Click to specify</p>
          )}
        </Card>
      ))}
    </div>
  );
}
