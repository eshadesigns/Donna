import React, { useState } from "react";
import { useLocation } from "wouter";
import { Sparkles, ArrowRight } from "lucide-react";
import { AppLayout } from "@/components/layout/app-layout";
import { Button, Input } from "@/components/ui/core";
import { useCreateTask } from "@/hooks/use-tasks";
import { motion } from "framer-motion";

export default function Home() {
  const [query, setQuery] = useState("");
  const [, setLocation] = useLocation();
  const createTask = useCreateTask();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    createTask.mutate({
      query: query.trim(),
      status: 'clarifying',
      context: {}
    }, {
      onSuccess: (task) => {
        setLocation(`/tasks/${task.id}`);
      }
    });
  };

  const suggestions = [
    "Book a table for 2 at an upscale sushi restaurant downtown tonight.",
    "Schedule a car service to the airport for tomorrow at 6 AM.",
    "Find a highly-rated corporate event space for 50 people.",
    "Order a premium floral arrangement to be delivered to the client."
  ];

  return (
    <AppLayout>
      <div className="h-full flex flex-col items-center justify-center px-4 max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="w-full text-center space-y-6"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/50 border border-white/5 text-sm text-muted-foreground mb-4">
            <Sparkles className="w-4 h-4 text-primary" />
            <span>Donna AI Assistant</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-display font-bold tracking-tight text-glow">
            Hello.<br/>
            <span className="text-muted-foreground font-medium">What can I handle for you?</span>
          </h1>

          <form onSubmit={handleSubmit} className="mt-12 relative max-w-2xl mx-auto w-full group">
            <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 to-primary/0 rounded-2xl blur opacity-25 group-focus-within:opacity-50 transition duration-1000"></div>
            <div className="relative flex items-center">
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask Donna to organize, book, or research..."
                className="h-16 pl-6 pr-14 text-lg rounded-2xl bg-card border-white/10 focus-visible:ring-primary/50 shadow-2xl"
              />
              <Button 
                type="submit" 
                size="icon" 
                variant="primary" 
                className="absolute right-2 h-12 w-12 rounded-xl"
                isLoading={createTask.isPending}
              >
                {!createTask.isPending && <ArrowRight className="w-5 h-5" />}
              </Button>
            </div>
          </form>

          <div className="pt-16 grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto text-left">
            {suggestions.map((suggestion, idx) => (
              <motion.button
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.2 + (idx * 0.1) }}
                onClick={() => setQuery(suggestion)}
                className="p-4 rounded-xl border border-white/5 bg-card/30 hover:bg-card/80 transition-all text-sm text-muted-foreground hover:text-foreground text-left"
              >
                {suggestion}
              </motion.button>
            ))}
          </div>
        </motion.div>
      </div>
    </AppLayout>
  );
}
