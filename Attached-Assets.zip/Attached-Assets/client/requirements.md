## Packages
framer-motion | Smooth page transitions and chat bubble animations
date-fns | Human-readable date formatting for timestamps
clsx | Conditional class merging for UI components
tailwind-merge | Tailwind class conflict resolution
lucide-react | Premium iconography for the minimal UI

## Notes
- App uses a sleek "Suits" inspired dark mode by default.
- Task status workflow is simulated via a "Dev Tools" dropdown in the UI for MVP demonstration.
- Notifications are polled every 3 seconds to demonstrate real-time updates.
