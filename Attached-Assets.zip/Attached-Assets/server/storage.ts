import { db } from "./db";
import { eq } from "drizzle-orm";
import {
  tasks,
  businesses,
  calls,
  notifications,
  type Task,
  type InsertTask,
  type Business,
  type InsertBusiness,
  type Call,
  type InsertCall,
  type Notification,
  type InsertNotification
} from "@shared/schema";

export interface IStorage {
  // Tasks
  getTask(id: number): Promise<Task | undefined>;
  getTasks(): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, updates: Partial<InsertTask>): Promise<Task>;

  // Businesses
  getBusinessesForTask(taskId: number): Promise<Business[]>;
  createBusiness(business: InsertBusiness): Promise<Business>;

  // Calls
  getCallsForBusiness(businessId: number): Promise<Call[]>;
  createCall(call: InsertCall): Promise<Call>;
  updateCall(id: number, updates: Partial<InsertCall>): Promise<Call>;

  // Notifications
  getNotifications(): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: number): Promise<Notification>;
}

export class DatabaseStorage implements IStorage {
  // Tasks
  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async getTasks(): Promise<Task[]> {
    return await db.select().from(tasks);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const [task] = await db.insert(tasks).values(insertTask).returning();
    return task;
  }

  async updateTask(id: number, updates: Partial<InsertTask>): Promise<Task> {
    const [task] = await db.update(tasks).set(updates).where(eq(tasks.id, id)).returning();
    return task;
  }

  // Businesses
  async getBusinessesForTask(taskId: number): Promise<Business[]> {
    return await db.select().from(businesses).where(eq(businesses.taskId, taskId));
  }

  async createBusiness(business: InsertBusiness): Promise<Business> {
    const [created] = await db.insert(businesses).values(business).returning();
    return created;
  }

  // Calls
  async getCallsForBusiness(businessId: number): Promise<Call[]> {
    return await db.select().from(calls).where(eq(calls.businessId, businessId));
  }

  async createCall(call: InsertCall): Promise<Call> {
    const [created] = await db.insert(calls).values(call).returning();
    return created;
  }

  async updateCall(id: number, updates: Partial<InsertCall>): Promise<Call> {
    const [call] = await db.update(calls).set(updates).where(eq(calls.id, id)).returning();
    return call;
  }

  // Notifications
  async getNotifications(): Promise<Notification[]> {
    return await db.select().from(notifications);
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [created] = await db.insert(notifications).values(notification).returning();
    return created;
  }

  async markNotificationRead(id: number): Promise<Notification> {
    const [notification] = await db.update(notifications).set({ read: true }).where(eq(notifications.id, id)).returning();
    return notification;
  }
}

export const storage = new DatabaseStorage();
