import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Tasks
  app.post(api.tasks.create.path, async (req, res) => {
    try {
      const input = api.tasks.create.input.parse(req.body);
      const task = await storage.createTask(input);
      res.status(201).json(task);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.get(api.tasks.get.path, async (req, res) => {
    const task = await storage.getTask(Number(req.params.id));
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }
    res.json(task);
  });

  app.get(api.tasks.list.path, async (req, res) => {
    const tasks = await storage.getTasks();
    res.json(tasks);
  });

  app.patch(api.tasks.update.path, async (req, res) => {
    try {
      const input = api.tasks.update.input.parse(req.body);
      const task = await storage.updateTask(Number(req.params.id), input);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(task);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // Businesses
  app.get(api.businesses.list.path, async (req, res) => {
    const taskId = Number(req.params.taskId);
    const results = await storage.getBusinessesForTask(taskId);
    res.json(results);
  });

  // Notifications
  app.get(api.notifications.list.path, async (req, res) => {
    const results = await storage.getNotifications();
    res.json(results);
  });

  // Seed DB if needed
  seedDatabase().catch(console.error);

  return httpServer;
}

async function seedDatabase() {
  const existingTasks = await storage.getTasks();
  if (existingTasks.length === 0) {
    const task = await storage.createTask({
      query: "Find me the 10 best salons near me for a blowout for Asian hair and book me the earliest appointment.",
      status: "done",
      context: { location: "San Francisco", date: "Earliest available", budget: "No limit" }
    });

    const b1 = await storage.createBusiness({
      taskId: task.id,
      name: "Silk & Scissors",
      details: "Specializes in Asian hair. Great reviews.",
      rating: "4.8",
      distance: "1.2 miles",
      isBookingAvailableOnline: false,
    });
    
    await storage.createCall({
      businessId: b1.id,
      status: "completed",
      summary: "Called to check availability. Booked for Tuesday at 10am.",
      bookingResult: "Booked - Tuesday 10am",
    });

    await storage.createNotification({
      taskId: task.id,
      message: "Silk & Scissors — Tuesday 10am, $85. Added to your calendar.",
      read: false,
    });
  }
}
